﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldBlock : MonoBehaviour {

    public float range;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {

    }

    void OnCollisionStay(Collision collision)
    {
        if(collision.gameObject.GetComponent<WorldBlock>())
        {
            float theta = Random.Range(0.0f, 360.0f);
            Vector3 up = new Vector3(
            -Mathf.Sin(theta * Mathf.PI / 180.0f),
            Mathf.Cos(theta * Mathf.PI / 180.0f),
            0);
            GetComponent<Transform>().position = up * Random.Range(range, range + 25.0f);
            GetComponent<Transform>().LookAt(new Vector3(0, 0, 0));
        }
    }
}
