﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    [SerializeField]
    public static float maxSpeed = 150;

    [SerializeField]
    private float rotateSpeed = 15;

    [SerializeField]
    private float accelerationFactor = 0.1f;

    [SerializeField]
    float restitutionFactor = 0.035f;

    private float maxBounciness = 6.0f;

    public static float bounciness = 1.0f;

    private Vector3 olderVel;

    public static Vector3 oldVel;

    [SerializeField]
    private GameObject speedUI = null;
    [SerializeField]
    private GameObject accelUI = null;
    [SerializeField]
    private GameObject restUI = null;
    [SerializeField]
    private GameObject gravUI = null;

    private bool escapedGravity = false;


    // Use this for initialization
    void Start ()
    {
    }

    void FixedUpdate()
    {
        olderVel = oldVel;
        oldVel = GetComponent<Rigidbody>().velocity;
        speedUI.GetComponent<Text>().text = "Speed:      " + oldVel.magnitude.ToString();
    }
	
	// Update is called once per frame
	void Update ()
    {
        float dist = Vector3.Distance(transform.position, new Vector3(0, 0, 0));
        float gravityScaler = 50 * (300.0f - dist) / 300.0f;
            //calculate gravity
        Physics.gravity = -Vector3.Normalize(transform.position) * gravityScaler;
        Vector3 right = Vector3.Normalize(new Vector3(
            Mathf.Cos(Mathf.PI/2) * Physics.gravity.x - Mathf.Sin(Mathf.PI/2) * Physics.gravity.y,
            Mathf.Sin(Mathf.PI/2) * Physics.gravity.x + Mathf.Cos(Mathf.PI/2) * Physics.gravity.y,
            0));

            //WIN CONDINTION
        if (dist > 300)
        {
            transform.position = new Vector3(0, 18.9f, 0);
            GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, 0, 0);
            bounciness = 1 - 0.2f * restitutionFactor;
            return;
        }
            //BOUNCINESS MANAGEMENT
        if (/*Input.GetKey(KeyCode.Space)*/ Input.touches.Length > 0 && bounciness < maxBounciness)
        {
            bounciness += restitutionFactor * Time.deltaTime;
            //bounciness += restitutionFactor * 0.5;
        }
        else if (bounciness > 1 - 0.2f * restitutionFactor)
        {
            bounciness -= restitutionFactor * Time.deltaTime;
            if (bounciness < 1 - 0.2f * restitutionFactor)
                bounciness = 1 - 0.2f * restitutionFactor;
        }

            //Change direction of acceleration
        float accelerationInput = Input.acceleration.x;
        if (accelerationInput > 0.3f) accelerationInput = 0.3f;
        if (accelerationInput < -0.3f) accelerationInput = -0.3f;
        accelerationInput *= -1 / 0.3f * 60;

            //update speed
        GetComponent<Rigidbody>().angularVelocity += new Vector3(0, 0, rotateSpeed) * accelerationFactor * accelerationInput * Time.deltaTime;
        GetComponent<Rigidbody>().velocity += right * -rotateSpeed * accelerationFactor * accelerationInput * Time.deltaTime;
        //if (!(Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.RightArrow)))
        //{
        //    if (Input.GetKey(KeyCode.LeftArrow) && GetComponent<Rigidbody>().velocity.z > -rotateSpeed)
        //    {
        //        GetComponent<Rigidbody>().angularVelocity += new Vector3(0, 0, rotateSpeed) * accelerationFactor;
        //        GetComponent<Rigidbody>().velocity += right * -rotateSpeed * accelerationFactor;
        //    }
        //    else if (Input.GetKey(KeyCode.RightArrow) && GetComponent<Rigidbody>().velocity.z < rotateSpeed)
        //    {
        //        GetComponent<Rigidbody>().angularVelocity += new Vector3(0, 0, -rotateSpeed) * accelerationFactor;
        //        GetComponent<Rigidbody>().velocity += right * rotateSpeed * accelerationFactor;
        //    }
        //}

            //Account for drag
        GetComponent<Rigidbody>().velocity -= GetComponent<Rigidbody>().velocity * 1.8f * Time.deltaTime;
        GetComponent<Rigidbody>().angularVelocity -= GetComponent<Rigidbody>().angularVelocity * 1.95f * Time.deltaTime;
        
            //CHECK IF EXCEDED
        if (Mathf.Abs(Vector3.Magnitude(GetComponent<Rigidbody>().velocity)) > maxSpeed)
        {
            GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, 0, 0);
            bounciness = 1 - 0.2f * restitutionFactor;
        }
        //Debug.Log(GetComponent<Rigidbody>().velocity);
        //Debug.Log(GetComponent<Rigidbody>().angularVelocity);
        //Debug.Log(bounciness);


        
        //Update UI elements
        accelUI.GetComponent<Text>().text = "Accel:      " + accelerationInput.ToString();
        gravUI.GetComponent<Text>().text  = "Gravity:    " + Physics.gravity.magnitude.ToString();
        restUI.GetComponent<Text>().text  = "Restitution " + bounciness.ToString();
    }

    void OnCollisionEnter(Collision collision)
    {
        GetComponent<Rigidbody>().velocity = olderVel;
        foreach (ContactPoint contact in collision.contacts)
        {
            float scaler = (Vector3.Magnitude(oldVel)) * bounciness;
            if (scaler < Physics.gravity.magnitude * 0.5f)
                scaler = Physics.gravity.magnitude * 0.5f;
            GetComponent<Rigidbody>().velocity = contact.normal * scaler;
        }
    }

    void OnCollisionStay(Collision collision)
    {
        GetComponent<Rigidbody>().velocity = olderVel;
        foreach (ContactPoint contact in collision.contacts)
        {
            float scaler = (Vector3.Magnitude(oldVel)) * bounciness;
            if (scaler < Physics.gravity.magnitude * 0.5f)
                scaler = Physics.gravity.magnitude * 0.5f;
            GetComponent<Rigidbody>().velocity = contact.normal * scaler;
        }
    }

    //void OnCollisionExit(Collision collision)
    //{
    //    speedUI.GetComponent<Text>().text = "";
    //}
}
