﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hudScaler : MonoBehaviour {

	// Use this for initialization
	void Start () {
        GetComponent<Transform>().localScale = new Vector3(Screen.width * 1.2f, Screen.height / 2, 1);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
