﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HudCamera : MonoBehaviour
{


    [SerializeField]
    private GameObject player;

    [SerializeField]
    private float zDist = 150.0f;

    // Use this for initialization
    void Start()
    {
        Vector2 pos = new Vector2(player.transform.position.x, player.transform.position.y);
        pos.Normalize();
        pos = pos * 150;
        transform.position = new Vector3(pos.x, pos.y, -zDist);

        //Texture2D texture = new Texture2D(Display.main.renderingWidth / 4, Display.main.renderingHeight/4);

        //GetComponent<Camera>().rect = new Rect(
        //    0,                                        //x
        //    1.0f - (0.25f * 388.0f / Display.main.renderingHeight), //y
        //            0.25f * 242.0f / Display.main.renderingWidth, //w
        //            0.25f * 388.0f / Display.main.renderingHeight //h
        //    );

    }

    // Update is called once per frame
    void Update()
    {
        Vector2 pos = new Vector2(player.transform.position.x, player.transform.position.y);
        pos.Normalize();
        pos = pos * 150;
        transform.position = new Vector3(pos.x, pos.y, -zDist);
      
        transform.LookAt(new Vector3(pos.x, pos.y, 0), -Physics.gravity);

    }
}
