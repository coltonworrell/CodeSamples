﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testingColorChanger : MonoBehaviour {

    [SerializeField]
    private float speed = 3;

    // Use this for initialization
    void Start ()
    {
    }
	
	// Update is called once per frame
	void Update () {
        float time = Time.fixedUnscaledTime;
        GetComponent<Renderer>().material.color = new Vector4(Mathf.Sin(time * 3 * speed), Mathf.Sin(time * 2 * speed), Mathf.Sin(time * 4 * speed), 1);
		
	}
}
