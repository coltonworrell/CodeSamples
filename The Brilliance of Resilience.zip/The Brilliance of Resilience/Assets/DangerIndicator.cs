﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DangerIndicator : MonoBehaviour {

    private float totalSize;
    private GameObject bouncinessBar;
    private GameObject dangerBar;

    private static int safegaurd = 1;
    

	// Use this for initialization
	void Start ()
    {
        if (safegaurd == 1)
        {
            safegaurd -= 1;
            bouncinessBar = GameObject.Instantiate(gameObject);
            dangerBar = GameObject.Instantiate(gameObject);

            bouncinessBar.GetComponent<Transform>().SetParent(GetComponent<Transform>());
            dangerBar.GetComponent<Transform>().SetParent(GetComponent<Transform>());

            bouncinessBar.GetComponent<SpriteRenderer>().sortingOrder = -2;
            dangerBar.GetComponent<SpriteRenderer>().sortingOrder = -3;

            bouncinessBar.GetComponent<Renderer>().material.color = new Color(0, 0, 1, 1);
            dangerBar.GetComponent<Renderer>().material.color = new Color(1, 0, 0, 1);

            bouncinessBar.GetComponent<Renderer>().material.color = new Color(0, 0, 1, 1);
            dangerBar.GetComponent<Renderer>().material.color = new Color(1.0f, 0.25f, 0, 1);
        }
        else
        {
            Destroy(gameObject.GetComponent<DangerIndicator>());
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
        float bounciness = Mathf.Min(PlayerController.bounciness / 6, 1.0f);
        float dangerBounciness;
        if (PlayerController.oldVel.magnitude * PlayerController.bounciness == 0.0f || Vector3.Angle(PlayerController.oldVel, Physics.gravity) > 90)
        {
            dangerBounciness = 0.0f;
        }
        else
        {
            dangerBounciness = 1.0f - Mathf.Min(150.0f / (PlayerController.oldVel.magnitude * PlayerController.bounciness) / 6.0f, 1.0f);
        }
        Debug.Log("db: " + dangerBounciness + " b: " + bounciness + " mag: " + PlayerController.oldVel.magnitude);

        bouncinessBar.transform.localPosition = new Vector3(0, -0.005f + 0.005f * bounciness, 0);
        bouncinessBar.transform.localScale = new Vector3(1, bounciness, 1);

        dangerBar.transform.localPosition = new Vector3(0, 0.005f - 0.005f * dangerBounciness, 0);
        dangerBar.transform.localScale = new Vector3(1, dangerBounciness, 1);

        float barDistance = (1 - dangerBounciness) - bounciness;
        if (barDistance > 0.5f)
        {
            float red = (barDistance - 0.5f) * 2.0f;
            bouncinessBar.GetComponent<Renderer>().material.color = new Color(1.0f - red, 1, 0, 1);
        }
        else
        {
            float green = barDistance * 2.0f;
            if (barDistance < 0.0f)
            {
                green = 0;
            }
            bouncinessBar.GetComponent<Renderer>().material.color = new Color(1, green, 0, 1);
        }

    }
}
