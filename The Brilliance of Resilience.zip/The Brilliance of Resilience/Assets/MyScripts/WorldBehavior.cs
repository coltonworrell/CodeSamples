﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldBehavior : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        /*
        float time = Time.fixedUnscaledTime;
        Vector3 up = Vector3.Normalize(new Vector3(
            -Mathf.Sin((15 * offsetNum * Mathf.PI / 180.0f ) + (time * 0.15f)),
            Mathf.Cos((15 * offsetNum * Mathf.PI / 180.0f) + (time * 0.15f)),
            0));
        transform.LookAt(transform.position - new Vector3(0, 0, -1), up);*/
    }
}
