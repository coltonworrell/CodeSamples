﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BounceyMeter : MonoBehaviour {

    private GameObject meterStick;
    // Use this for initialization
    void Start ()
    {
        Vector3 size = new Vector3(0.05f * 10, 0.00555555f * 5, 1);
        Vector3 pos = new Vector3(1.5f, -1, 0.1f);
        meterStick = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        meterStick.transform.localScale = new Vector3(0.05f * 1.2f, 0.00555555f * 7.5f * 1.2f, 0.000000001f);
        meterStick.GetComponent<Transform>().SetParent(GetComponent<Transform>());
        for (int i = 0; i < 14; ++i)
        {
            GameObject newObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            newObj.GetComponent<Transform>().SetParent(GetComponent<Transform>());
            newObj.GetComponent<Transform>().localPosition = pos + new Vector3(0.5f * size.x, 0, 0);
            newObj.GetComponent<Transform>().localScale = size;
            Color color = (new Color(1, 1.0f - (i / 13.0f), 1.0f - (i / 13.0f), Random.Range(0.0f, 1.0f)));
            newObj.GetComponent<Renderer>().material.SetColor("_EmissionColor", color);
            pos.y += 2 / 12.0f;
            size.x *= 1.1f;
        }


        //Destroy(gameObject);

    }
	
	// Update is called once per frame
	void Update ()
    {
		float bounciness = Mathf.Min(PlayerController.bounciness / 4, 1.0f);
        Color color = (new Color(1, 1.0f - bounciness, 1.0f - bounciness, 1));
        meterStick.GetComponent<Renderer>().material.SetColor("_EmissionColor", color);
        meterStick.transform.localPosition = new Vector3(4, -1.125f + bounciness * 2.25f, 0.1f);

    }
}
