To import the deprecated Glow 3.0.7 package delete the current mk glow folder and then import this package.
The deprecated package will be removed in a future release.