﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {


    [SerializeField]
    private GameObject player;

    [SerializeField]
    private float zDist = 15.0f;

    // Use this for initialization
    void Start ()
    {
        transform.position = player.transform.position + new Vector3(0, 0, -zDist) - 5 * Physics.gravity.normalized;
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        float colorMod = (300.0f - Vector3.Distance(transform.position, new Vector3(0, 0, 0))) / 300.0f;
        transform.position = player.transform.position + new Vector3(0, 0, -zDist);
        transform.LookAt(player.transform.position, -Physics.gravity);
        GetComponent<Camera>().backgroundColor = new Color(0.20703125f * colorMod, 0.6171875f * colorMod, 0.8671875f * colorMod, 1);

    }
}
