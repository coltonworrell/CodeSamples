﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Speedometer : MonoBehaviour {

    private GameObject meterStick;
    void Start()
    {
        int count = 14;
        for (int i = 0; i < count; ++i)
        {
            GameObject newObj = GameObject.CreatePrimitive(PrimitiveType.Quad);
            newObj.GetComponent<Transform>().SetParent(GetComponent<Transform>());
            float theta = 95.0f + (80.0f * (i / (count - 1.0f)));
            Vector3 up = new Vector3(
            -Mathf.Sin(theta * Mathf.PI / 180.0f),
            Mathf.Cos(theta * Mathf.PI / 180.0f),
            0);
            newObj.transform.localRotation = Quaternion.EulerAngles(0,0, theta * Mathf.PI / 180.0f);
            newObj.GetComponent<Transform>().localPosition = up * 0.1f;
            newObj.GetComponent<Transform>().localScale = new Vector3(0.0025f, 0.01f, 0.01f);
            Color color = (new Color(1, (i / 13.0f), (i / 13.0f), Random.Range(0.0f, 1.0f)));
            newObj.GetComponent<Renderer>().material.SetColor("_EmissionColor", color);
        }
        meterStick = GameObject.CreatePrimitive(PrimitiveType.Quad);
        meterStick.transform.localScale = new Vector3(0.0025f * 10, 0.01f * 70, 0.01f);
        meterStick.GetComponent<Transform>().SetParent(GetComponent<Transform>());
    }

    void Update()
    {
        float percent = PlayerController.oldVel.magnitude / PlayerController.maxSpeed;
        float theta = 175.0f - (80.0f * percent);
        Vector3 up = new Vector3(
        -Mathf.Sin(theta * Mathf.PI / 180.0f),
        Mathf.Cos(theta * Mathf.PI / 180.0f),
        0);
        meterStick.transform.localRotation = Quaternion.EulerAngles(0, 0, theta * Mathf.PI / 180.0f);
        meterStick.GetComponent<Transform>().localPosition = up * 0.05f + new Vector3(0, 0, -0.1f);

        Color color = (new Color(1, percent, percent, 1));
        meterStick.GetComponent<Renderer>().material.SetColor("_EmissionColor", color);

        //Color color = (new Color(1, 1.0f - (i / 13.0f), 1.0f - (i / 13.0f), Random.Range(0.0f, 1.0f)));
        //newObj.GetComponent<Renderer>().material.SetColor("_EmissionColor", color);

    }
}
