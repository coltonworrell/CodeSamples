/// @ref core
/// @file glm/common.hpp

#pragma once

#include "detail/func_common.hpp"
