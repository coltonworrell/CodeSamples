﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldGen : MonoBehaviour {

    [SerializeField]
    int objectCount = 80;

	// Use this for initialization
	void Start () {
        int objects = 9;
        for(int i = 0; i < 10; ++i)
        {
            for (int j = 0; j < objects; ++j)
            {
                float theta = Random.Range(0.0f, 360.0f);
                Vector3 up = new Vector3(
                -Mathf.Sin(theta * Mathf.PI / 180.0f),
                Mathf.Cos(theta * Mathf.PI / 180.0f),
                0);

                GameObject newObj;
                if (true/*Random.Range(0, 2) == 0*/)
                {
                    theta = Random.Range(0.0f, 360.0f);
                    newObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    //new Vector3(
                    //-Mathf.Sin(theta * Mathf.PI / 180.0f),
                    //Mathf.Cos(theta * Mathf.PI / 180.0f),
                    //0));
                    newObj.transform.localScale = new Vector3(1, Random.Range(3.0f, 9.0f), 2);
                }
                else
                {
                    newObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    float size = Random.Range(1.0f, 5.0f);
                    newObj.transform.localScale = new Vector3(size, size, size);
                }
                newObj.transform.position = up * Random.Range(25.0f + i * 25.0f, 25.0f + i * 25.0f + 25.0f);
                newObj.transform.LookAt(new Vector3(0, 0, 0));
                newObj.GetComponent<Renderer>().material.color = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), 1);
                newObj.AddComponent<WorldBlock>();
                newObj.AddComponent<Rigidbody>();
                newObj.GetComponent<Rigidbody>().collisionDetectionMode = CollisionDetectionMode.Continuous;
                newObj.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
                newObj.GetComponent<WorldBlock>().range = 25.0f + i * 25.0f;
            }

            objects += objects / 3;
        }

    }
	
}
